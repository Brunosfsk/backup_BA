import styled from 'styled-components';


export const Butu = styled.button`
color: #fff;
background-color: orange;
border: none;
padding: 5px 20px;
border-radius: 3px;
Cursor: pointer;
// position: absolute;
// bottom: 12px;
width: 100%;
height: 50px;
font-size: 20px;
`;





