import React from 'react';
import * as Styled from './styles'

function ButtonAdicionar() {
  return (
      <div>
        <Styled.ButtonAdicionar>ADD</Styled.ButtonAdicionar>
      </div>
  );

  }
export default ButtonAdicionar;