import styled from 'styled-components';


export const ButtonAdicionar = styled.button`
  color: #000;
  background-color: blue;
  border-radius: 10px;
`;



