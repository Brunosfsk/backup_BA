import styled from 'styled-components';


export const Button_Sacola = styled.button`
  color: #fff;
  background-color: orange;
  border: none;
  padding: 5px 20px;
  border-radius: 3px;
  Cursor: pointer;
`;



