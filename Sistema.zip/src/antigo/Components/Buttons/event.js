const { EventEmitter } = require("events");
const eventEmitter = new EventEmitter();
export default eventEmitter;