import styled from 'styled-components';

export const ContainerVitrine = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
`;

export const Chamada = styled.h2`
  font-size: 22px;
  margin-top: 75px;
  text-align: center;
`;